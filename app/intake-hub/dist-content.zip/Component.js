sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("poc.sp.hub.intakehub.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map