sap.ui.define(["sap/fe/core/AppComponent"],function(e){"use strict";return e.extend("poc.sp.hub.sourcingproject.Component",{metadata:{manifest:"json"}})});
//# sourceMappingURL=Component.js.map